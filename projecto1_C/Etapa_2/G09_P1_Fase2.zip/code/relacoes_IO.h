#include "relacoes.h"

int relacoes_inserir (long long nif,Grafo *g);
int relacoes_apagar (long long nif,Grafo *g);
int ver_relacao(long long nif,Grafo *g);
int relacao_distancia(long long nif,Grafo *g,int peso);
