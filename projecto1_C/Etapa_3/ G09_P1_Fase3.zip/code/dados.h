#include <stdio.h>

int get_int();
void converte_ll_str(long long numero, char *numstr);
int getsw(int dim,char *string);
long long ler_nif();
void ler_input(char *dado,char* input, int dim,int row,int col);
int response();
int ler_numero_int(char *string);
long long ler_numero_ll(char *string);
char* est_civil();
