#ifndef _ESTRUTURAS_H_
#define _ESTRUTURAS_H_
   #include "estruturas.h"
#endif

int print_user(Perfil *user);
int pesquisa_nome();
int pesquisa_nif();
int findByName(char *name);
int editar(long long nif);
int criar_user(long long *IdUsers);
